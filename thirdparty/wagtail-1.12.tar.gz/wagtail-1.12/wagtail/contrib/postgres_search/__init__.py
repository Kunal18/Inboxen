default_app_config = 'wagtail.contrib.postgres_search.apps.PostgresSearchConfig'
