from wagtail.wagtailsearch.views.frontend import search  # noqa
