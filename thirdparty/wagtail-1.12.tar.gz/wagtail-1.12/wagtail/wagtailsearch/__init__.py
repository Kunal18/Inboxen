default_app_config = 'wagtail.wagtailsearch.apps.WagtailSearchAppConfig'
