from wagtail.wagtailsearch.urls.frontend import urlpatterns  # noqa
