from .conf import APIField  # noqa


default_app_config = 'wagtail.api.apps.WagtailAPIAppConfig'
