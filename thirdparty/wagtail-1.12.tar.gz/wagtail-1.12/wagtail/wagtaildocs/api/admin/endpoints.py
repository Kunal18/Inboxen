from __future__ import absolute_import, unicode_literals

from ..v2.endpoints import DocumentsAPIEndpoint


class DocumentsAdminAPIEndpoint(DocumentsAPIEndpoint):
    pass
