from __future__ import absolute_import, unicode_literals

import threading

_local = threading.local()


def get_request():
    return getattr(_local, "request", None)


def get_script_nonce_attr():
    """
    Either returns a nonce attr (including leading space) or an empty string
    """
    nonce = getattr(get_request(), "csp_nonce", "")
    nonce_attr = ' nonce="{0}"'.format(nonce) if nonce else ''

    return nonce_attr
