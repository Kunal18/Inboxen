from __future__ import absolute_import, unicode_literals


class RemovedInWagtail113Warning(DeprecationWarning):
    pass


removed_in_next_version_warning = RemovedInWagtail113Warning


class RemovedInWagtail114Warning(PendingDeprecationWarning):
    pass
