default_app_config = 'wagtail.wagtailredirects.apps.WagtailRedirectsAppConfig'
