default_app_config = 'wagtail.wagtailsnippets.apps.WagtailSnippetsAppConfig'
