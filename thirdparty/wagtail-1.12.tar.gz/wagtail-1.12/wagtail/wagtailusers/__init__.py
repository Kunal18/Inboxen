default_app_config = 'wagtail.wagtailusers.apps.WagtailUsersAppConfig'
