Authors
=======

* Matthew Westcott (Torchbox) twitter: @gasmanic
* David Cranwell (Torchbox) twitter: @davecranwell
* Karl Hobley (Torchbox) twitter: @kaedroho
* Tim Heap (Takeflight)
* Josh Barr (Springload)

Contributors
============

* Helen Chapman helen.chapman@torchbox.com
* Balazs Endresz balazs.endresz@torchbox.com
* Neal Todd neal.todd@torchbox.com
* Paul Hallett (twilio) hello@phalt.co
* Tom Dyson
* Serafeim Papastefanos
* Łukasz Bołdys
* peterarenot
* Levi Gross
* Delgermurun Purevkhuu
* Lewis Cowper
* Stephen Newey
* Ryan Foster
* v1kku
* Miguel Vieira
* Ben Emery
* David Smith
* Ben Margolis
* Tom Talbot
* Jeffrey Hearn
* Robert Clark
* Nathan Brizendine
* thenewguy
* John-Scott Atlakson
* Eric Drechsel
* Alejandro Giacometti
* Robert Rollins
* linibou
* Timo Rieber
* Jerel Unruh
* georgewhewell
* Frank Wiles
* Sebastian Spiegel
* Alejandro Varas
* Martin Sanders
* Benoît Bar
* Claudemiro
* Tiago Henriques
* Arne Schauf
* Jordi Joan
* Damian Moore
* signalkraft
* Mac Chapman
* Brett Grace
* Nar Chhantyal
* Michael Fillier
* Mitchel Cabuloy
* Piet Delport
* Tom Christie
* Michael van Tellingen
* Scot Hacker
* Kyungil Choi
* Joss Ingram
* Christoph Lipp
* Michael Cordover
* Timothy Allen
* Rob Shelton
* Anurag Sharma
* Maximilian Stauss
* Salvador Faria
* Alex Gleason
* Ryan Pineo
* Petr Vacha
* Sævar Öfjörð Magnússon
* Ashia Zawaduk
* Denis Voskvitsov
* Kyle Stratis
* Sergey Nikitin
* John Draper
* Rich Brennan
* Alex Bridge
* Tamriel
* LKozlowski
* Matthew Downey
* Maris Serzans
* Shu Ishida
* Ben Kerle
* Christian Peters
* Adon Metcalfe
* rayrayndwiga
* Rich Atkinson
* jnns
* Eugene MechanisM
* Benjamin Bach
* Alexander Bogushov
* Aarni Koskela
* alexpilot11
* Peter Quade
* Josh Hurd
* Matt Fozard
* Chris Rogers
* Josh Schneier
* Mikalai Radchuk
* Charlie Choiniere
* Nigel Fletton
* Kait Crawford
* Adam Bolfik
* Thomas Winter
* Gareth Price
* Liam Brenner
* Nicolas Kuttler
* Mike Dingjan
* Loic Teixeira
* Juha Kujala
* Eirik Krogstad
* Rob Moorman
* Matthijs Melissen
* Jonas Lergell
* Danielle Madeley
* Janneke Janssen
* Roel Bruggink
* Yannick Chabbert
* Andy Babic
* Tomas Olander
* Andrew Tork Baker
* Vincent Audebert
* Jack Paine
* Nick Smith
* João Luiz Lorencetti
* Jason Morrison
* Mario César
* Moritz Pfeiffer
* David Seddon
* Brad Busenius
* Juha Yrjölä
* Bojan Mihelac
* Robert Moggach
* Stephen Rice
* Behzad Nategh
* Yann Fouillat (Gagaro)
* Jonny Scholev
* Richard McMillan
* Johannes Spielmann
* Franklin Kingma
* Ludolf Takens
* Oktay Altay
* Bertrand Bordage
* Paul J Stevens
* kakulukia
* Raphael Stolt
* Tim Graham
* Thibaud Colas
* Tobias Schmidt
* Chris Darko
* Aymeric Augustin
* Adriaan Tijsseling
* sebworks
* Sean Muck
* Fábio Macêdo Mendes
* Eraldo Energy
* Jesse Legg
* Tim Leguijt
* Luiz Boaretto
* Jonathon Moore
* Kees Hink
* Jayden Smith
* emg36
* Stein Strindhaug
* Žan Anderle
* Mattias Loverot
* Ricky Robinett
* Axel Haustant
* Henk-Jan van Hasselaar
* alexfromvl
* Jaap Roes
* Ducky
* Shawn Makinson
* Tom Miller
* Luca Perico
* Gary Krige
* Hammy Goonan
* Thejaswi Puthraya
* Benoît Vogel
* Manuel E. Gutierrez
* Albert O'Connor
* Morgan Aubert
* Diederik van der Boor
* Sean Hoefler
* Edd Baldry
* PyMan Claudio Marinozzi
* Jeffrey Chau
* Craig Loftus
* MattRijk
* Marco Fucci
* Mihail Russu
* Robert Slotboom
* Erick M'bwana
* Andreas Nüßlein
* John Heasly
* Nikolai Røed Kristiansen
* Alex Zagorodniuk
* glassresistor
* Mikael Svensson
* Peter Baumgartner
* Matheus Bratfisch
* Andy Chosak
* Kevin Whinnery
* Martey Dodoo
* David Ray
* Alasdair Nicol
* Tobias McNulty
* Vorlif
* Kjartan Sverrisson
* LB (Ben Johnston)
* Christine Ho
* Trent Holliday
* jacoor
* hdnpl
* Tom Hendrikx
* Ralph Jacobs
* Wietze Helmantel
* Patrick Gerken
* Will Giddens
* Maarten Kling
* Huub Bouma
* Thijs Kramer
* Ramon de Jezus
* Ross Curzon-Butler
* Daniel Chimeno
* Medhat Assaad
* Sebastian Bauer
* Martin Hill
* Maurice Bartnig
* Eirikur Ingi Magnusson
* Harris Lapiroff
* Hugo van den Berg
* Olly Willans
* Ben Enright
* Alice Rose
* John Franey
* Marc Tudurí
* Lucas Moeskops
* Rob van der Linde
* Paul Kamp
* dwasyl
* Eugene Morozov
* Levi Adler
* Edwar Baron
* Tomasz Knapik

Translators
===========

* Afrikaans: Jaco du Plessis
* Arabic: alfuhigi, Roger Allen, Ahmad Kiswani, Mohamed Mayla
* Basque: Unai Zalakain
* Bulgarian: Lyuboslav Petrov
* Catalan: Antoni Aloy, David Llop, Roger Pons
* Chinese: hanfeng, Lihan Li, Leway Colin, Orangle Liu
* Chinese (China): hanfeng, Daniel Hwang, Jian Li, Listeng Teng, Feng Wang, Fred Zeng, Joey Zhao, Vincent Zhao, zhushajun
* Chinese (Taiwan): gogobook, Lihan Li, Jp Shieh
* Croatian (Croatia): Luka Matijević
* Czech: Ales Dvorak, Ivan Pomykacz, Jiri Stepanek, Marek Turnovec, Stanislav Vasko
* Danish: Asger Sørensen
* Dutch: benny_AT_it_digin.com, Bram, Brecht Dervaux, Huib Keemink, Thijs Kramer, Samuel Leeuwenburg, mahulst, Rob Moorman, Michael van Tellingen, Arne Turpyn
* Dutch (Netherlands): Bram, Franklin Kingma, Maarten Kling, Thijs Kramer
* Finnish: Eetu Häivälä, Niklas Jerva, Aarni Koskela, Rauli Laine, Glen Somerville, Juha Yrjölä
* French: Adrien, Timothy Allen, Sebastien Andrivet, Bertrand Bordage, André Bouatchidzé, Tom Dyson, Antonin Enfrun, Axel Haustant, Léo, Pierre Marfoure, nahuel, Dominique Peretti, Benoît Vogel
* Galician: fooflare
* Georgian: André Bouatchidzé
* German: Ettore Atalan, Patrick Craston, Henrik Kröger, Tammo van Lessen, Martin Löhle, Wasilis Mandratzis-Walz, Daniel Manser, m0rph3u5, Max Pfeiffer, Moritz Pfeiffer, Herbert Poul, Karl Sander, Tobias Schmidt, Johannes Spielmann, Raphael Stolt, Jannis Vajen, Vorlif, Matthew Westcott
* Greek: Jim Dal, George Giannoulopoulos, Yiannis Inglessis, Wasilis Mandratzis-Walz, Nick Mavrakis, NeotheOne, Serafeim Papastefanos
* Hebrew (Israel): Lior Abazon, bjesus, Yossi Lalum
* Hungarian: Laszlo Molnar, Kornél Novák Mergulhão
* Icelandic (Iceland): Arnar Tumi Þorsteinsson, Kjartan Sverrisson, Sævar Öfjörð Magnússon
* Indonesian (Indonesia): Sutrisno Efendi, Geek Pantura
* Italian: Edd Baldry, Claudio Bantaloukas, Gian-Maria Daffre, Giacomo Ghizzani, Carlo Miron, Alessio Di Stasio, Andrea Tagliazucchi
* Japanese: Sangmin Ahn, Shu Ishida, Daigo Shitara, Shimizu Taku
* Korean: Kyungil Choi, Jihan Chung
* Latvian: Reinis Rozenbergs, Maris Serzans
* Lithuanian: Matas Dailyda
* Mongolian: Delgermurun Purevkhuu
* Norwegian Bokmål: Eirik Krogstad, Robin Skahjem-Eriksen
* Persian: Mohammad reza Jelveh, Mohammad Hossein Mojtahedi, Py Zenberg
* Polish: Konrad Lalik, Mateusz, Miłosz Miśkiewicz, Bartek Sielicki, utek, Grzegorz Wasilewski
* Portuguese (Brazil): Claudemiro Alves Feitosa Neto, Bruno Bertoldi, Luiz Boaretto, Gladson Brito, Thiago Cangussu, Gilson Filho, Joao Garcia, João Luiz Lorencetti, Marcio Mazza, Douglas Miranda, Guilherme Nabanete
* Portuguese (Portugal): Gladson Brito, Thiago Cangussu, Tiago Henriques, Jose Lourenco, Nuno Matos, Douglas Miranda, Manuela Silva
* Romanian: Dan Braghis
* Russian: ajk, Andrey Avdey, Daniil, gsstver, Sergey Khalymon, Sergey Komarov, Eugene MechanisM, Rustam Mirzaev, Mikalai Radchuk, Alexandr Romantsov, Nikita Viktorovich, Vassiliy Vorobyov
* Slovak (Slovakia): Stevo Backor, dellax, Jozef Karabelly
* Slovenian: Mitja Pagon
* Spanish: Mauricio Baeza, Daniel Chimeno, fonso, fooflare, José Luis, Joaquín Tita, Unai Zalakain
* Swedish: Jim Brouzoulis, Alexander Holmbäck, André Karlsson, Jon Karlsson, Ludwig Kjellström, Thomas Kunambi, Hannes Lohmander
* Turkish: Cihad Gündoǧdu
* Turkish (Turkey): Saadettin Yasir Akel, Cihad Gündoǧdu, José Luis, Ragıp Ünal
* Ukrainian: Mykola Zamkovoi
* Vietnamese: Luan Nguyen
